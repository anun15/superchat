#ifndef _GUI_H
#define _GUI_H

#include <signal.h>
#include <assert.h>
#include <ncurses.h>
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <sstream>
#include <iostream>
#include<pthread.h>
#include<vector>
#include"Window.h"
#include"Chatroom.h"
#include<unistd.h>

#define WIDTH 30
#define HEIGHT 6

using namespace std;

extern vector <string> choices;
extern vector <string> recieve_message;
extern vector <string> recieve_user;


extern string uNick;
extern int n_choices;
extern int startx;
extern int starty;
extern int last_size, cur_size;
extern int position;
extern int unlock;
extern WINDOW *cur_chatroom;
extern WINDOW *users;


void Menu();
void* gui(void *z);
void print_menu(WINDOW *menu_win, int highlight);
bool checkUser(char nick[8]);
void start();
int menu_refresh(WINDOW *temp_win);
void print_in_middle(WINDOW *win, int starty, int startx, int width, char *string);
void send_message(string m);
void clearH(int val, WINDOW *chatrooms);



#endif
