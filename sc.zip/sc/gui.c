#include <stdio.h>
#include <ncurses.h>
#include <string.h>


#define WIDTH 30
#define HEIGHT 6

int startx = 0;
int starty = 0;

char *choices[] = {
			"Sign In",
			"Sign Up",
			"Exit",
		  };
int n_choices = sizeof(choices) / sizeof(char *);
void print_menu(WINDOW *menu_win, int highlight);

int main()
{	WINDOW *menu_win;
	int highlight = 1;
	int choice = 0;
	int c;
	int row,col;

	char main[]="Welcome to SuperChat";
	char title[]="New User";
	char title2[]="Sign In";
  char mesg[]="Nick:";
  char mesg1[]="First Name:";
  char mesg2[]="Last Name:";
  char mesg3[]="Date of Birth:";
  char mesg4[]="E-mail:";
	char signin[]="Enter Your Nick:";


	char fname[10];
  char lname[10];
  char nick[8];
  char email[25];
  char dob[10];

	char str[80];

	initscr();
	clear();
	noecho();
	cbreak();	/* Line buffering disabled. pass on everything */
	startx = (80 - WIDTH) / 2;
	starty = (20 - HEIGHT) / 2;
	getmaxyx(stdscr,row,col);

	menu_win = newwin(HEIGHT, WIDTH, starty, startx);
	keypad(menu_win, TRUE);
	mvprintw(row/2-10,(col-strlen(main))/2,"%s",main);
	refresh();
	print_menu(menu_win, highlight);
	while(1)
	{	c = wgetch(menu_win);
		switch(c)
		{	case KEY_UP:
				if(highlight == 1)
					highlight = n_choices;
				else
					--highlight;
				break;
			case KEY_DOWN:
				if(highlight == n_choices)
					highlight = 1;
				else
					++highlight;
				break;
			case 10:
				choice = highlight;
				break;
			default:
				refresh();
				break;
		}
		print_menu(menu_win, highlight);
		if(choice != 0)	/* User did a choice come out of the infinite loop */
			break;
	}
	clear();
	echo();
	refresh();
	if(choice == 1)
	{
		getmaxyx(stdscr,row,col);		/* get the number of rows and columns */
	  mvprintw(row/2-2,(col-strlen(title))/2,"%s",title2);
		mvprintw(row/2,(col-strlen(signin))/2-10,"%s",signin);
	  getstr(nick);
	}
	else if (choice==2)
	{
		getmaxyx(stdscr,row,col);		/* get the number of rows and columns */
	  mvprintw(row/2-2,(col-strlen(title))/2,"%s",title);
	  mvprintw(row/2,(col-strlen(mesg))/2-7,"%s",mesg);
	  getstr(nick);
	  mvprintw(row/2+1,(col-strlen(mesg1))/2-10,"%s",mesg1);
	  getstr(fname);
	  mvprintw(row/2+2,(col-strlen(mesg2))/2-10,"%s",mesg2);
	  getstr(lname);
	  mvprintw(row/2+3,(col-strlen(mesg3))/2-12,"%s",mesg3);
	  getstr(dob);
	  mvprintw(row/2+4,(col-strlen(mesg4))/2-12,"%s",mesg4);
	  getstr(email);

		FILE *fp;
	  fp = fopen("Output.txt", "a");
	  fprintf(fp,"%s %s %s %s %s \n" ,nick, fname, lname, email, dob);
	  fclose(fp);
	}

	clrtoeol();
	refresh();
	getch();
	endwin();
	return 0;
}


void print_menu(WINDOW *menu_win, int highlight)
{
	int x, y, i;

	x = 2;
	y = 2;
	box(menu_win, 0, 0);
	for(i = 0; i < n_choices; ++i)
	{	if(highlight == i + 1) /* High light the present choice */
		{	wattron(menu_win, A_REVERSE);
			mvwprintw(menu_win, y, x, "%s", choices[i]);
			wattroff(menu_win, A_REVERSE);
		}
		else
			mvwprintw(menu_win, y, x, "%s", choices[i]);
		++y;
	}
	wrefresh(menu_win);
}
