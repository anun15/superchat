This is an example program to help with the semester project

 %   git clone https://github.com/bdavisCSE3320/SuperChat.git

 %  cd SuperChat/

 %  vi scripts/release.com 

 % # Edit the file scripts/release.com to point to the opensplice distribution directory.  

 % # (change the OSPL_HOME environment variable)

 %  make clean

 %  make

 %  bin/SuperChat


