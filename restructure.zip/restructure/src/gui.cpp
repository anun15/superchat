/*Alex, Dawsen, Abdul, Kevin: Code production for the GUI: started 3/19/17 5:36 PM*/
/*large majority of code taken from NCurses example*/
/*USE: currently operates to allow access to previous uses or to allow new users to be added to the system*/

#include"gui.h"
vector <string> choices;
vector <string> recieve_message;
vector <string> recieve_user;
string uNick;
int n_choices;
int startx = 0;
int starty = 0;
int last_size, cur_size;
int row,col;
int unlock = 0;



void* gui(void* z)
{
  choices.push_back("Sign In");
  choices.push_back("Sign Up");
  choices.push_back("EXIT");
  start();


	return z;

}

void start()
{
  WINDOW *menu_win;
  int choice;



  n_choices = choices.size();
  initscr();
	clear();
	noecho();
	cbreak();



  startx = (80 - WIDTH) / 2;
	starty = (20 - HEIGHT) / 2;

  getmaxyx(stdscr,row,col);
	menu_win = newwin(HEIGHT, WIDTH, starty, startx);
	keypad(menu_win, TRUE);
	mvprintw(starty-2,startx+3,"Welcome To SuperChat");
	refresh();
  choice = menu_refresh(menu_win);

  char fname[10];
  char lname[10];
  char nick[8];
  char email[25];
  char dob[10];
  char temp[1];
  //int unlock;

	if(choice == 1)
	{
		getmaxyx(stdscr,row,col);		/* get the number of rows and columns */
	  mvprintw(row/2-2,(col-strlen("Sign In"))/2,"Sign In"); //title 2 = "sign in"
		mvprintw(row/2,(col-strlen("Enter Your Nick:"))/2-10,"Enter Your Nick:"); // signiman = "Enter Your Nick"
	  getstr(nick);
    //printf("getstr did not segfault\n");
	/*uses checkUser method to find if the user is already in the system*/
		if(checkUser(nick))
		{
      uNick = nick;
			mvprintw(row/2+2,(col-strlen("User found"))/2-10,"User found");
			getstr(temp);
      /*cur_chatroom = newwin(LINES-5,(3*COLS)/4,1,(COLS/4)+1);
      box(cur_chatroom, 0, 0);*/
      unlock = 1;

			Menu();
		}
		else
		{
			mvprintw(row/2+2,(col-strlen("Invalid nick"))/2-10,"Invalid nick");
			getstr(temp);
      clear();
      start();
		}

	}

    /*if the user chooses to signup this path is chosen
     prints out a set of user requests for information*/
	else if (choice==2)
	{
		getmaxyx(stdscr,row,col);		/* get the number of rows and columns */
	  mvprintw(row/2-2,(col-strlen("New User"))/2,"New User");
	  mvprintw(row/2,(col-strlen("Nick:"))/2-7,"Nick:");
	  getstr(nick);
    uNick = nick;
	  mvprintw(row/2+1,(col-strlen("First Name:"))/2-10,"First Name:");
	  getstr(fname);
	  mvprintw(row/2+2,(col-strlen("Last Name:"))/2-10,"Last Name:");
	  getstr(lname);
	  mvprintw(row/2+3,(col-strlen("Date of Birth"))/2-12,"Date of Birth:");
	  getstr(dob);
	  mvprintw(row/2+4,(col-strlen("E-mail:"))/2-12,"E-mail:");
	  getstr(email);
        /*creates an output file whose data is comma seperated and
         entire blocks are seperated by semi-colons*/
		FILE *fp;
	  fp = fopen("UserInfo.txt", "a");
	  fprintf(fp,"%s,%s,%s,%s,%s\n" ,nick, fname, lname, email, dob);
	  fclose(fp);


    unlock = 1;
		Menu();

	}
	else if (choice == 3)
	{
		return;
	}
	choice = 0;

	clrtoeol();
	refresh();
	endwin();


}

int menu_refresh(WINDOW *temp_win){
  int c;
  int decision;
  int highlight = 1;
  while(1)
{
   clear();
   echo();
   refresh();

   print_menu(temp_win, highlight);
   while(1)
   {
      c = wgetch(temp_win);
      switch(c)
      {
          case KEY_UP:
          if(highlight == 1)
            highlight = n_choices;
          else
            --highlight;
          break;
          case KEY_DOWN:
            if(highlight == n_choices)
              highlight = 1;
            else
              ++highlight;
          break;
          case 10:
            decision = highlight;
            break;
          default:
            refresh();
          break;
  }
  print_menu(temp_win, highlight);
      /* User did a choice come out of the infinite loop */
  if(decision != 0)
    break;
}
clear();
echo();
refresh();

return decision;
}
}
void print_menu(WINDOW *menu_win, int highlight)
{
	int x, y, i;

	x = 2;
	y = 2;
	box(menu_win, 0, 0);
	for(i = 0; i < n_choices; ++i)
	{	if(highlight == i + 1) /* High light the present choice */
		{	wattron(menu_win, A_REVERSE);
			mvwprintw(menu_win, y, x, "%s", choices[i].c_str());
			wattroff(menu_win, A_REVERSE);
		}
		else
			mvwprintw(menu_win, y, x, "%s", choices[i].c_str());
		++y;
	}
	wrefresh(menu_win);
}

/*checks to see if the user is already in the system or not
returns valid if the user is in the UserInfo.txt file
and returns false otherwise*/
bool checkUser(char nick[8])
{
	FILE *fp;
	char buffer[1000];
//	char* fnametxt;
//	char* lnametxt;
	char* nicktxt;
//	char* emailtxt;
//	char* dobtxt;
	int isFound = 0;



	fp = fopen("UserInfo.txt","r");

	while(fgets(buffer,1000, fp)!= NULL)
	{
		nicktxt = strtok(buffer, ",");
	/*	fnametxt = strtok(NULL,del);
		lnametxt = strtok(NULL, del);
		emailtxt = strtok(NULL, del);
		dobtxt = strtok(NULL, del);
		if((strcmp(fnametxt, fname) == 0) && (strcmp(lnametxt, lname) == 0) && (strcmp(nicktxt ,nick) == 0) && (strcmp(emailtxt, email) == 0) && (strcmp(dobtxt, dob) == 0))
		{
			isFound = 1;
			break;
		}	*/
		if(strcmp(nicktxt,nick) == 0)
		{
			isFound = 1;
		}
	}



	fclose(fp);
	return isFound;
}

void Menu(){
  char mess[100];
  char test[] = "Users";
  int on_chatroom = 0;
  clear();
  refresh();
  WINDOW *chatrooms, *text_box;

  keypad(text_box, TRUE);
  users = newwin(LINES/2,COLS/4,1,1);
  box(users, 0, 0);
  mvwprintw(users, 0, ((COLS/4)-strlen("Users"))/2, "Users");
  chatrooms = newwin((LINES/2)-2, COLS/4,(LINES/2)+1,1);
  box(chatrooms, 0, 0);
  mvwprintw(chatrooms, 0, ((COLS/4)-strlen("Chatrooms"))/2, "Chatrooms");

  start_color();			/* Start color 			*/
  init_pair(2, COLOR_RED, COLOR_WHITE);
  wattron(chatrooms,COLOR_PAIR(2));
  mvwprintw(chatrooms, 2, ((COLS/4)-strlen("Chatrooms"))/2, "Public");
  wattroff(chatrooms,COLOR_PAIR(2));

  mvwprintw(chatrooms, 3, ((COLS/4)-strlen("Chatrooms"))/2, "Chatroom2");
  mvwprintw(chatrooms, 4, ((COLS/4)-strlen("Chatrooms"))/2, "Chatroom3");
  mvwprintw(chatrooms, 5, ((COLS/4)-strlen("Chatrooms"))/2, "Chatroom4");
  mvwprintw(chatrooms, 6, ((COLS/4)-strlen("Chatrooms"))/2, "Chatroom5");
  mvwprintw(chatrooms, 7, ((COLS/4)-strlen("Chatrooms"))/2, "Chatroom6");
  mvwprintw(chatrooms, 8, ((COLS/4)-strlen("Chatrooms"))/2, "Chatroom7");
  mvwprintw(chatrooms, 9, ((COLS/4)-strlen("Chatrooms"))/2, "Chatroom8");
  mvwprintw(chatrooms, 10, ((COLS/4)-strlen("Chatrooms"))/2, "Chatroom9");
  mvwprintw(chatrooms, 11, ((COLS/4)-strlen("Chatrooms"))/2, "Chatroom10");

  //cur_chatroom = newwin(LINES-5,(3*COLS)/4,1,(COLS/4)+1);
  text_box = newwin(4,(3*COLS)/4,LINES-4,(COLS/4)+1);
  cur_chatroom = newwin(LINES-5,(3*COLS)/4,1,(COLS/4)+1);
  box(cur_chatroom, 0, 0);
  mvwprintw(cur_chatroom, 0, (((3*COLS)/4)-strlen("Current Chatroom"))/2, "Current Chatroom");
  wrefresh(cur_chatroom);


  //refresh();
  wrefresh(users);		/* Start color 			*/


//box(cur_chatroom, 0, 0);


  //getch();
  //endwin();
  //refresh();




  //refresh();
  wrefresh(chatrooms);



  //Chatroom chatroom, avail_chat, text_box;
	//Window users;
	//WINDOW* user_win,*avail_win,*chatroom_win, *text_box_win;
//  int starty, startx, width, string;
//  start_color();
//  init_pair(1, COLOR_RED, COLOR_BLACK); //This doesnt work either
	/*Creation of User Window screen
    -still needs to refresh every 2.5 seconds
    -check for online users
  */
	//users.set_size(LINES/2,COLS/4,/*(LINES-5)/2*/1,/*(COLS - 10)/2*/1,"Users");
	//user_win = users.create_window();


  //users.print_in_middle(user_win,LINES/2,COLS/4,1,test,COLOR_PAIR(1));
  //users.display_messages(user_win);
  /*
    -Needs to display available chatrooms
    (Probably going to be identified by global variable)

  */
	//avail_chat.set_size((LINES/2)-1, COLS/4,(LINES/2)+1,1,"Chatrooms");
	//avail_win = avail_chat.create_window();
  //TESTING chatrooms
  //choices[0] = "Chatroom1";
  //choices[1] = "Chatroom2";
  //choices[2] = "Chatroom3";
  //choices.push_back("Chatroom4");
  //  print_menu(avail_win, 1);

  //avail_chat.print_in_middle(avail_win,LINES/2,COLS/4,1,test,COLOR_PAIR(1));

  /*
    -Needs to create a textbox at the bottom of chatroom form

  */
	//chatroom.set_size(LINES-5,(3*COLS)/4,1,(COLS/4)+1,"Current Chatroom");
	//chatroom_win = chatroom.create_window();

  //text_box.set_size(4,(3*COLS)/4,LINES-4,(COLS/4)+1,"Enter a Message");
	//text_box_win = text_box.create_window();

  //getmaxyx(text_box_win,row,col);
  //mvwprintw(text_box_win,row/2, (col - strlen("Message:"))/2,"Message:"); // signiman = "Enter Your Nick"
  //getstr(message);

  //chatroom.print_in_middle(chatroom_win,LINES/2,COLS/4,1,test,COLOR_PAIR(1));
  /*for(int i = 1; i <= 10; i++){
  chatroom.display_messages(chatroom_win, uNick, "This is a message");
  avail_chat.display_rooms(avail_chat_win, "Chatroom");
  sleep(1);
}*/
  //Currently Working On Text Box Below. Doesnt seem to work
  //chatroom.TextBox(chatroom_win);

 //int position = 1;
	while(1)
  {
    box(text_box, 0, 0);
    //refresh();
    wrefresh(text_box);
    mvwprintw(text_box, 1, 1, "Message:");
    wgetstr(text_box,mess);

    if(mess[0] == '/' && mess[1] == 'E' )       //command to exit ncurses
    {
      break;
    }
    else if(mess[0] == '/' && mess[1] == 'N' && mess[2] =='N' )    //command to change nick
    {

    }
    else if(mess[0] == '/' && mess[1] == 'C' && mess[2] =='R' )    //command to change chat room
    {

      if(mess[3] == 'P')
      {
        if(on_chatroom != 0)
        {
          on_chatroom = 0;
          recieve_message.clear();
          wclear(cur_chatroom);
          wrefresh(cur_chatroom);
        }
      }
      if(mess[3] == '2')
      {
        if(on_chatroom != 1)
        {
          on_chatroom = 1;
          wclear(cur_chatroom);

        }
      }
      if(mess[3] == '3')
      {
        if(on_chatroom != 2)
        {
          on_chatroom = 2;
          wclear(cur_chatroom);
        }
      }
      if(mess[3] == '4')
      {
        if(on_chatroom != 3)
        {
          on_chatroom = 3;
          wclear(cur_chatroom);
        }
      }
      if(mess[3] == '5')
      {
        if(on_chatroom != 4)
        {
          on_chatroom = 4;
          wclear(cur_chatroom);
        }
      }
      if(mess[3] == '6')
      {
        if(on_chatroom != 5)
        {
          on_chatroom = 5;
          wclear(cur_chatroom);
        }
      }
      if(mess[3] == '7')
      {
        if(on_chatroom != 6)
        {
          on_chatroom = 6;
          wclear(cur_chatroom);
        }
      }
      if(mess[3] == '8')
      {
        if(on_chatroom != 7)
        {
          on_chatroom = 7;
          wclear(cur_chatroom);
        }
      }
      if(mess[3] == '9')
      {
        if(on_chatroom != 8)
        {
          on_chatroom = 8;
          wclear(cur_chatroom);
        }
      }
      if(mess[3] == '1' && mess[4] =='0')
      {
        if(on_chatroom != 9)
        {
          on_chatroom = 9;
          wclear(cur_chatroom);
        }
      }
    }
    else
    {
    last_size = recieve_message.size();
    recieve_user.push_back(uNick);
    recieve_message.push_back(mess);
    cur_size = recieve_message.size();
  }

    //sleep(1);

    wclear(text_box);
    refresh();

  }
}


void print_in_middle(WINDOW *win, int starty, int startx, int width, char *string)
{	int length, x, y;
	float temp;

	if(win == NULL)
		win = stdscr;
	getyx(win, y, x);
	if(startx != 0)
		x = startx;
	if(starty != 0)
		y = starty;
	if(width == 0)
		width = 80;

	length = strlen(string);
	temp = (width - length)/ 2;
	x = startx + (int)temp;
	mvwprintw(win, y, x, "%s", string);
	refresh();
}

void send_message(string m){
//  mvwprintw(text_box, 1, 1, "Message:");
  //wgetstr(text_box,messageInstance.message);
  return;
}
