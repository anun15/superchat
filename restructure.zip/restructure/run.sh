make clean
make
bin/SuperChat
