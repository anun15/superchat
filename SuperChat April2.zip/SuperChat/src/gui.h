#ifndef _GUI_H
#define _GUI_H

#include <signal.h>
#include <assert.h>
#include <ncurses.h>
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <sstream>
#include <iostream>
#include<pthread.h>
#include<vector>
#include"Window.h"
#include"Chatroom.h"
#include<unistd.h>

#define WIDTH 30
#define HEIGHT 6

using namespace std;

extern vector <string> choices;
extern vector <string> recieve_message;

extern string uNick;
extern int n_choices;
extern int startx;
extern int starty;
extern int last_size, cur_size;


void Menu();
void* gui(void *z);
void print_menu(WINDOW *menu_win, int highlight);
bool checkUser(char nick[8]);



#endif
