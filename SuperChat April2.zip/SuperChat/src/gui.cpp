/*Alex, Dawsen, Abdul, Kevin: Code production for the GUI: started 3/19/17 5:36 PM*/
/*large majority of code taken from NCurses example*/
/*USE: currently operates to allow access to previous uses or to allow new users to be added to the system*/

#include"gui.h"
vector <string> choices;
vector <string> recieve_message;
string uNick;
int n_choices;
int startx = 0;
int starty = 0;
int last_size, cur_size;

void* gui(void* z)
{
  WINDOW *menu_win;
  choices.push_back("Sign In");
  choices.push_back("Sign Up");
  choices.push_back("EXIT");
  n_choices = choices.size();
	int highlight = 1;
	int choice = 0;
	int c;
	int row,col;

/*choice options and layout*/
	char main[]="Welcome to SuperChat";
	char title[]="New User";
	char title2[]="Sign In";
  char mesg[]="Nick:";
  char mesg1[]="First Name:";
  char mesg2[]="Last Name:";
  char mesg3[]="Date of Birth:";
  char mesg4[]="E-mail:";
	char signin[]="Enter Your Nick:";
	char temp[1];
/*parameters given by the user, later used for user construction in superchat*/
	char fname[10];
  char lname[10];
  char nick[8];
  char email[25];
  char dob[10];

	char str[80];

	initscr();
	clear();
	noecho();
	cbreak();	/* Line buffering disabled. pass on everything */

    /*environment variables to construct windows based on terminal size of screen*/

	startx = (80 - WIDTH) / 2;
	starty = (20 - HEIGHT) / 2;
	getmaxyx(stdscr,row,col);


	menu_win = newwin(HEIGHT, WIDTH, starty, startx);
	keypad(menu_win, TRUE);
	//mvprintw(row/2-10,(col-strlen(main))/2,"%s",main);
	mvprintw(starty-2,startx+3,"%s",main);
	refresh();

    /*prints menu window with highlight capabilities*/
    while(1)
{
	clear();
        echo();
        refresh();

	print_menu(menu_win, highlight);

    /*endless loop that terminates once the user has selected an option
     this first user selection contains whether the user wants to login
     signup or exit the current screen*/
	while(1)
	{	c = wgetch(menu_win);
		switch(c)
		{	case KEY_UP:
				if(highlight == 1)
					highlight = n_choices;
				else
					--highlight;
				break;
			case KEY_DOWN:
				if(highlight == n_choices)
					highlight = 1;
				else
					++highlight;
				break;
			case 10:
				choice = highlight;
				break;
			default:
				refresh();
				break;
		}
		print_menu(menu_win, highlight);
        /* User did a choice come out of the infinite loop */
		if(choice != 0)
			break;
	}
	clear();
	echo();
	refresh();

    /*if the user wants to login this path is chosen*/
	if(choice == 1)
	{
		getmaxyx(stdscr,row,col);		/* get the number of rows and columns */
	  mvprintw(row/2-2,(col-strlen(title))/2,"%s",title2);
		mvprintw(row/2,(col-strlen(signin))/2-10,"%s",signin);
	  getstr(nick);
    //printf("getstr did not segfault\n");
	/*uses checkUser method to find if the user is already in the system*/
		if(checkUser(nick))
		{
      uNick = nick;
			mvprintw(row/2+2,(col-strlen(signin))/2-10,"User found");
			getstr(temp);

			/*WINDOW *menu = newwin(HEIGHT,WIDTH,startx,starty);
			choices[0] = "Create a Chatroom";
			choices[1] = "Chatroom 2";
			choices[2] = "Chatrrom 3";
			print_menu(menu,highlight);*/
			Menu();
		}
		else
		{
			mvprintw(row/2+2,(col-strlen(signin))/2-10,"Invalid nick");
			getstr(temp);
		}

	}

    /*if the user chooses to signup this path is chosen
     prints out a set of user requests for information*/
	else if (choice==2)
	{
		getmaxyx(stdscr,row,col);		/* get the number of rows and columns */
	  mvprintw(row/2-2,(col-strlen(title))/2,"%s",title);
	  mvprintw(row/2,(col-strlen(mesg))/2-7,"%s",mesg);
	  getstr(nick);
	  mvprintw(row/2+1,(col-strlen(mesg1))/2-10,"%s",mesg1);
	  getstr(fname);
	  mvprintw(row/2+2,(col-strlen(mesg2))/2-10,"%s",mesg2);
	  getstr(lname);
	  mvprintw(row/2+3,(col-strlen(mesg3))/2-12,"%s",mesg3);
	  getstr(dob);
	  mvprintw(row/2+4,(col-strlen(mesg4))/2-12,"%s",mesg4);
	  getstr(email);
        /*creates an output file whose data is comma seperated and
         entire blocks are seperated by semi-colons*/
		FILE *fp;
	  fp = fopen("UserInfo.txt", "a");
	  fprintf(fp,"%s,%s,%s,%s,%s\n" ,nick, fname, lname, email, dob);
	  fclose(fp);
		Menu();

	}
	else if (choice == 3)
	{
		break;
	}
	choice = 0;
	}
	clrtoeol();
	refresh();
	getch();
	endwin();
	return z;

}


void print_menu(WINDOW *menu_win, int highlight)
{
	int x, y, i;

	x = 2;
	y = 2;
	box(menu_win, 0, 0);
	for(i = 0; i < n_choices; ++i)
	{	if(highlight == i + 1) /* High light the present choice */
		{	wattron(menu_win, A_REVERSE);
			mvwprintw(menu_win, y, x, "%s", choices[i].c_str());
			wattroff(menu_win, A_REVERSE);
		}
		else
			mvwprintw(menu_win, y, x, "%s", choices[i].c_str());
		++y;
	}
	wrefresh(menu_win);
}

/*checks to see if the user is already in the system or not
returns valid if the user is in the UserInfo.txt file
and returns false otherwise*/
bool checkUser(char nick[8])
{
	FILE *fp;
	char buffer[1000];
	char* fnametxt;
	char* lnametxt;
	char* nicktxt;
	char* emailtxt;
	char* dobtxt;
	int isFound = 0;



	fp = fopen("UserInfo.txt","r");

	while(fgets(buffer,1000, fp)!= NULL)
	{
		nicktxt = strtok(buffer, ",");
	/*	fnametxt = strtok(NULL,del);
		lnametxt = strtok(NULL, del);
		emailtxt = strtok(NULL, del);
		dobtxt = strtok(NULL, del);
		if((strcmp(fnametxt, fname) == 0) && (strcmp(lnametxt, lname) == 0) && (strcmp(nicktxt ,nick) == 0) && (strcmp(emailtxt, email) == 0) && (strcmp(dobtxt, dob) == 0))
		{
			isFound = 1;
			break;
		}	*/
		if(strcmp(nicktxt,nick) == 0)
		{
			isFound = 1;
		}
	}



	fclose(fp);
	return isFound;
}

void Menu(){
  char test[] = "Users";
  clear();
  Chatroom chatroom, avail_chat;
	Window users;
	WINDOW* user_win,*avail_chat_win,*chatroom_win;
  int starty, startx, width, string;
  start_color();
  init_pair(1, COLOR_RED, COLOR_BLACK); //This doesnt work either
	/*Creation of User Window screen
    -still needs to refresh every 2.5 seconds
    -check for online users
  */
	users.set_size(LINES/2,COLS/4,/*(LINES-5)/2*/1,/*(COLS - 10)/2*/1,"Users");
	user_win = users.create_window();
  users.print_in_middle(user_win,LINES/2,COLS/4,1,test,COLOR_PAIR(1));
  //users.display_messages(user_win);
  /*
    -Needs to display available chatrooms
    (Probably going to be identified by global variable)

  */
	avail_chat.set_size((LINES/2)-1, COLS/4,(LINES/2)+1,1,"Chatrooms");
	avail_chat_win = avail_chat.create_window();

  /*
    -Needs to create a textbox at the bottom of chatroom form

  */
	chatroom.set_size(LINES-1,(3*COLS)/4,1,(COLS/4)+1,"Current Chatroom");
	chatroom_win = chatroom.create_window();
  /*for(int i = 1; i <= 10; i++){
  chatroom.display_messages(chatroom_win, uNick, "This is a message");
  avail_chat.display_rooms(avail_chat_win, "Chatroom");
  sleep(1);
}*/
  //Currently Working On Text Box Below. Doesnt seem to work
  //chatroom.TextBox(chatroom_win);


	while(1){
    if(cur_size - last_size != 0){
      for(int k = last_size; k < cur_size; k++ ){
          chatroom.display_messages(chatroom_win, uNick, recieve_message[k]);
        }
	  }
      sleep(1);
  }
}
