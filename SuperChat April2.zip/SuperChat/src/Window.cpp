#include"Window.h"
#include<ncurses.h>
#include<iostream>
#include<string>
#include<vector>
#include<string.h>

using namespace std;

Window::Window(){
    initscr();	/* Start curses mode 		*/
    cbreak();
    keypad(stdscr, TRUE);

}
void Window::set_size(int h, int w, int sy, int sx, string t){
  height = h;
  width = w;
  starty = sy;
  startx = sx;
  title = t;

  return;
}
WINDOW* Window::create_window(){
  refresh();


  keypad(stdscr, TRUE);
  my_win = newwin(height, width, starty, startx);


	box(my_win, 0, 0);
  mvwprintw(my_win,0,(width - title.size())/2,"%s",title.c_str());
  refresh();
	wrefresh(my_win);

	return my_win;
}
void Window::remove_window(){
  wborder(my_win, ' ', ' ', ' ',' ',' ',' ',' ',' ');
  wrefresh(my_win);
  delwin(my_win);
  return;
}

void Window::get_size(int h, int w, int sy, int sx, string t){
  h = height;
  w = width;
  starty = sy;
  startx = sx;
  title = t;
}

void Window::print_in_middle(WINDOW *win, int starty, int startx, int width, char *string, chtype color)
{	int length, x, y;
	float temp;

	if(win == NULL)
		win = stdscr;
	getyx(win, y, x);
	if(startx != 0)
		x = startx;
	if(starty != 0)
		y = starty;
	if(width == 0)
		width = 80;

	length = strlen(string);
	temp = (width - length)/ 2;
	x = startx + (int)temp;
	wattron(win, color);
	mvwprintw(win, y, x, "%s", string);
	wattroff(win, color);
	refresh();
}
