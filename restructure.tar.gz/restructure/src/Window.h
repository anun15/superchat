#ifndef CHATROOM_H
#define CHATROOM_H
#include<iostream>
#include<ncurses.h>
#include<string>

using namespace std;

class Window{
private:
  WINDOW *my_win;
  int height, width, starty, startx, ch;
  string title;
public:
  Window();
  void set_size(int h, int w, int sy, int sx, string t);
  WINDOW* create_window();
  void remove_window();
  void get_size(int h, int w, int sy, int sx, string t);
  void print_in_middle(WINDOW *win, int starty, int startx, int width, char *string, chtype color);
};
#endif
