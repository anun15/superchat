#include<iostream>
#include<stdio.h>
#include<ncurses.h>
#include"Chatroom.h"
#include"Window.h"
#include"form.h"
#include<unistd.h>

using namespace std;

Chatroom::Chatroom(){
  position = 1;

}

void Chatroom::display_messages(WINDOW *my_win,string uNick,string message){
    mvwprintw(my_win,position++,1,"%s: %s",uNick.c_str(),message.c_str());
    wrefresh(my_win);
}
void Chatroom::display_rooms(WINDOW *my_win,string room){
  mvwprintw(my_win,position++,1,"%s",room.c_str());
  wrefresh(my_win);
}
void Chatroom::TextBox(WINDOW *my_win){

	keypad(my_win, TRUE);
  field[0] = new_field(10, 15, 18, 1, 0, 0);
	field[1] = NULL;

  set_field_back(field[0], A_UNDERLINE); 	/* Print a line for the option 	*/
	field_opts_off(field[0], O_AUTOSKIP);

  my_form = new_form(field);
	post_form(my_form);
	wrefresh(my_win);

  mvprintw(4, 10, "Enter a Message: ");
	wrefresh(my_win);
}
