#ifndef _CHATROOM__H
#define _CHATROOM__H
#include"Window.h"
#include"form.h"
#include<string>
#include<iostream>
using namespace std;

class Chatroom : public Window{
private:
  int position;
  FIELD *field[2];
	FORM  *my_form;
	int ch;

public:
   Chatroom();
   void display_messages(WINDOW *my_win, string uNick,string message);
   void display_rooms(WINDOW *my_win, string room);
   void TextBox(WINDOW *my_win);
};

#endif
